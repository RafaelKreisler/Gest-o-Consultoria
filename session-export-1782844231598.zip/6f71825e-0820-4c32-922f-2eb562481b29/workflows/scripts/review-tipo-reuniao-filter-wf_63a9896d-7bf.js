export const meta = {
  name: 'review-tipo-reuniao-filter',
  description: 'Revisao adversarial do filtro Tipo de Reuniao (cruzamento por e-mail) no painel da Consultoria',
  phases: [ { title: 'Review' }, { title: 'Verify' } ],
}

const FILE = 'C:/Users/rafael.kreisler_suno/Downloads/painel-gestao-consultoria-main/painel-gestao-consultoria-main/index.html';

const FINDINGS_SCHEMA = {
  type:'object', additionalProperties:false,
  properties:{
    findings:{ type:'array', items:{
      type:'object', additionalProperties:false,
      properties:{
        severity:{type:'string', enum:['bug','regression','edge-case','nit']},
        title:{type:'string'},
        location:{type:'string'},
        explanation:{type:'string'},
        suggested_fix:{type:'string'}
      }, required:['severity','title','location','explanation','suggested_fix']
    }}
  }, required:['findings']
};
const VERDICT_SCHEMA = {
  type:'object', additionalProperties:false,
  properties:{ isReal:{type:'boolean'}, reasoning:{type:'string'} },
  required:['isReal','reasoning']
};

const SPEC = `Arquivo: ${FILE} (HTML unico, JS vanilla, sem build).
MUDANCA: novo filtro "Tipo de Reuniao". Coluna real "Tipo de chamada e reuniao" (normaliza para tipo_de_chamada_e_reuniao; alias canonico tipo_reuniao). Requisitos:
- A coluna existe SO na base de reunioes (RAW.reunioes). NAO existe em leads nem vendas (confirmado em dados reais: 19811/19811 reunioes preenchidas, leads/vendas sem a coluna).
- Deteccao defensiva: TIPO_IN_REUNIOES (em detectSdrCloserColumns) = existe valor nao-vazio em reunioes.
- Reunioes filtradas DIRETAMENTE por tipo via passSdrCloser(row, hasSdr, hasCloser, hasTipo), chamado por filteredReuniones com hasTipo=TIPO_IN_REUNIOES.
- Leads NUNCA filtrados por tipo (filteredLeads passa hasTipo=false).
- Vendas NAO tem a coluna -> filtradas por CRUZAMENTO DE E-MAIL em filteredVendas: quando TIPO_IN_REUNIOES && SEL.tipoReuniao.size>0, mostra so vendas cujo e-mail (lowercase trim) pertence a uma reuniao REALIZADA (isRealizada) do(s) tipo(s) selecionado(s), derivado de filteredReuniones().filter(isRealizada).
- Deve propagar para: Funil Geral, Funil Comparativo, Diaria de Vendas (Metas Captacao/Origem/breakdowns Source/Funil/Estrategia/Fonte/Closer), Tabela Dinamica (pivot buildPivotTree), Cohort (renderCohort).
- Quando nada selecionado OU coluna ausente: comportamento identico ao anterior (nao-quebra).
Verificacao ja feita ao vivo (dados reais, tipo "[ADV] Consultores"): Leads 45605 (inalterado), Marcadas 879, Realizadas 448, Vendas 896->56, todas as 56 vendas linkadas a realizadas do tipo; ao limpar volta a 896.`;

const LENSES = [
  { key:'crossref', focus:'Correcao do cruzamento por e-mail e consistencia do funil. Verifique: (a) normalizacao de e-mail identica entre reunioes (r.email) e vendas (v.email); (b) o dedup por e-mail dentro de filteredReuniones afeta o conjunto de e-mails das realizadas? (c) vendas com e-mail vazio; (d) reunioes realizadas sem e-mail; (e) custo: filteredVendas chama filteredReuniones (que e O(n)) e filteredVendas e chamado varias vezes por render — risco de lentidao?' },
  { key:'regression', focus:'Nao-regressao quando filtro inativo. As guardas (TIPO_IN_REUNIOES && SEL.tipoReuniao.size>0) estao corretas em filteredVendas? passSdrCloser foi atualizado em TODAS as chamadas com a 4a posicao correta (filteredLeads=false, filteredReuniones=TIPO_IN_REUNIOES)? passGlobalVendas NAO deve checar tipo diretamente (vendas nao tem a coluna). Algum efeito colateral quando a coluna nao existe?' },
  { key:'propagation', focus:'Propagacao por TODAS as views. Procure qualquer ponto que use RAW.vendas ou RAW.reunioes DIRETO (sem filteredVendas/filteredReuniones) onde o filtro de tipo deveria valer e nao vai valer (ex.: renderCohort constroi emailToCriacao de RAW.leads — ok; mas confira o uso de vendas/reunioes). Confira renderFunilComparativo, buildPivotTree, renderVendasBreakdown/Chart, renderCohort.' },
  { key:'asymmetry', focus:'Assimetria e wiring de dados. tipo NAO filtra leads; filtra reunioes direto; COL_ALIASES.tipo_reuniao cobre "tipo_de_chamada_e_reuniao"; populateAllFilters monta opcoes do multi-select a partir de [leads,reunioes,vendas] (leads/vendas dao undefined -> filtrados). clearFilters e buildAllMS iteram SEL/MS_CFG e portanto cobrem tipoReuniao automaticamente? O botao "Todos" do multi-select funciona p/ tipo?' },
];

phase('Review');
const results = await pipeline(
  LENSES,
  lens => agent(`${SPEC}\n\nLEIA o arquivo ${FILE} (use Read/Grep) e revise SOB ESTA LENTE:\n${lens.focus}\n\nReporte apenas achados CONCRETOS e reais (bug/regression/edge-case/nit) com localizacao (funcao/linha) e correcao sugerida. Se nao houver problema real sob a lente, retorne findings vazio.`,
    { label:`review:${lens.key}`, phase:'Review', schema: FINDINGS_SCHEMA }),
  (review, lens) => parallel(((review && review.findings) || []).map(f => () =>
    agent(`Verifique adversarialmente este achado sobre a mudanca em ${FILE}. LEIA o codigo relevante e confirme se procede DE FATO. Seja cetico: se for falso-positivo, comportamento intencional, ou ja tratado, marque isReal=false. Na duvida, isReal=false.\n\nAchado (lente ${lens.key}): ${JSON.stringify(f)}`,
      { label:`verify:${(f.title||'').slice(0,28)}`, phase:'Verify', schema: VERDICT_SCHEMA })
      .then(v => ({ ...f, lens: lens.key, verdict: v }))
  ))
);
const all = results.flat().filter(Boolean);
const confirmed = all.filter(f => f.verdict && f.verdict.isReal);
return { totalFindings: all.length, confirmadosReais: confirmed.length, confirmed };
